#include "transport_guide_manager.h"


int main()
{
	TransportGuideManager manager;

	manager.PerformQueries();

	return 0;
}