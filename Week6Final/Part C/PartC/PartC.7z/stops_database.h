#pragma once
#include <string>
#include <iostream>
#include <string>
#include <unordered_map>
#include <set>
#include <optional>
#include <memory>


class GroundPoint
{
public:
    GroundPoint()
    {
		latitude_ = longitude_ = 0;
    }

    GroundPoint(double lat, double lon) : 
    latitude_(lat), longitude_(lon) {}

	static double ComputeDistance(const GroundPoint& lhs, 
		const GroundPoint& rhs);

private:
	double latitude_, longitude_;

	constexpr static double PI = 3.1415926535;
	constexpr static double EARTH_RADIUS = 6371000;

	friend std::istream& operator>>(std::istream& input, 
		GroundPoint& point);

	friend std::ostream& operator<<(std::ostream& output,
		const GroundPoint& point);

	friend bool operator!=(const GroundPoint& lhs, 
		const GroundPoint& rhs);

	friend void TestReadGroundPoint();
};


struct BusStop
{
	std::string name;

	GroundPoint coordinate;

	std::unordered_map<std::string, unsigned> distance_to_other_stops;
};


std::istream& operator>>(std::istream& input, BusStop& bus_stop);


class BusStopStats
{
public:
	BusStopStats() = default;

	void AddBusInStat(const std::string& bus);

	[[nodiscard]] const std::set<std::string>& GetStat() const;

	[[nodiscard]] const std::unordered_map<std::string, unsigned>& 
		GetDistanceToOtherStops() const;

	void SetCoordinate(const GroundPoint& coordinate);

	void SetDistanceToOtherStops(const std::unordered_map<std::string, unsigned>& other_stops);

	[[nodiscard]] const GroundPoint& GetCoordinate() const;

private:
	GroundPoint coordinate_;

	std::set<std::string> buses_on_stop_;

	std::unordered_map<std::string, unsigned> distance_to_other_stops_;
};


class BusStopsDataBase
{
public:
	BusStopsDataBase() = default;

	void AddStop(const BusStop& bus_stop);

	[[nodiscard]] double ComputeDirectDistanceBetweenStops(
		const std::string& from, const std::string& to) const;

	[[nodiscard]] uint64_t ComputeRealDistanceBetweenStops(
		const std::string& from, const std::string& to) const;

	void AddBusOnStop(const std::string& bus, const std::string& stop);

	using BusStopResponse = std::pair<std::string, 
    std::optional<std::set<std::string>>>;

	[[nodiscard]] BusStopResponse GetBusStopStat(const std::string& stop) const;

private:
	std::unordered_map<std::string, 
    std::shared_ptr<BusStopStats>> bus_stops_;

	friend void TestBusStopsDataBase();
};


std::ostream& operator<<(std::ostream& output, 
	const BusStopsDataBase::BusStopResponse& response);


std::pair<std::string, unsigned> ParseDistanceToStop(std::string_view line);
